package com.example.wificardmonitor

import android.app.Activity
import android.app.AppOpsManager
import android.app.AlertDialog
import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.DateFormat
import java.util.Date
import java.util.concurrent.TimeUnit

data class Card(
    val id: Long,
    var name: String,
    var totalBytes: Long,
    var durationMs: Long,
    var startedAt: Long,
    var startBytes: Long,
    var usedBytes: Long = 0L,
    var active: Boolean = true
)

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("cards", Context.MODE_PRIVATE) }
    private val cards = mutableListOf<Card>()
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private val GB = 1024.0 * 1024.0 * 1024.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadCards()
        buildUi()
        refreshCards()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(0xFFF5F7FA.toInt())
        }
        val title = TextView(this).apply {
            text = "📶 مراقب كروت الإنترنت"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(0xFF16324F.toInt())
            setPadding(0, 8, 0, 18)
        }
        status = TextView(this).apply {
            textSize = 14f
            setTextColor(0xFF444444.toInt())
            setPadding(8, 8, 8, 16)
        }
        val add = Button(this).apply {
            text = "＋ إضافة كرت جديد"
            setOnClickListener { showAddDialog() }
        }
        val access = Button(this).apply {
            text = "تفعيل صلاحية قياس استهلاك Wi‑Fi"
            setOnClickListener { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        }
        val refresh = Button(this).apply {
            text = "تحديث الاستهلاك"
            setOnClickListener { refreshCards() }
        }
        root.addView(title)
        root.addView(status)
        root.addView(add)
        root.addView(access)
        root.addView(refresh)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun hasUsageAccess(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            android.os.Process.myUid(),
            packageName
        ) == AppOpsManager.MODE_ALLOWED
    }

    private fun currentWifiBytes(): Long? {
        if (!hasUsageAccess()) return null
        return try {
            val nsm = getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
            val bucket = nsm.querySummaryForDevice(
                ConnectivityManager.TYPE_WIFI, null, 0L, System.currentTimeMillis()
            )
            bucket.rxBytes + bucket.txBytes
        } catch (_: Exception) { null }
    }

    private fun showAddDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 8, 28, 0)
        }
        val name = EditText(this).apply { hint = "اسم الكرت (اختياري)" }
        val gb = EditText(this).apply {
            hint = "حجم الباقة بالجيجابايت"
            inputType = 8194
        }
        val hours = EditText(this).apply {
            hint = "مدة الكرت بالساعات"
            inputType = 8194
        }
        box.addView(name); box.addView(gb); box.addView(hours)
        AlertDialog.Builder(this)
            .setTitle("بيانات الكرت")
            .setView(box)
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("بدء المتابعة") { _, _ ->
                val size = gb.text.toString().toDoubleOrNull()
                val duration = hours.text.toString().toDoubleOrNull()
                if (size == null || duration == null || size <= 0 || duration <= 0) {
                    Toast.makeText(this, "أدخل حجمًا ومدة صحيحين", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                if (!hasUsageAccess()) {
                    Toast.makeText(this, "فعّل صلاحية قياس الاستخدام أولًا، ثم أضف الكرت", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                    return@setPositiveButton
                }
                val baseline = currentWifiBytes()
                if (baseline == null) {
                    Toast.makeText(this, "تعذر قراءة إحصاءات Wi‑Fi على هذا الهاتف", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                cards.add(Card(
                    System.currentTimeMillis(), name.text.toString().ifBlank { "كرت ${cards.size + 1}" },
                    (size * GB).toLong(), TimeUnit.HOURS.toMillis(duration),
                    System.currentTimeMillis(), baseline
                ))
                saveCards()
                refreshCards()
            }.show()
    }

    private fun refreshCards() {
        val now = System.currentTimeMillis()
        val current = currentWifiBytes()
        status.text = if (hasUsageAccess()) {
            "صلاحية قياس الاستخدام: مفعّلة\nقد تختلف قراءة الهاتف عن عداد مزوّد الشبكة."
        } else {
            "يلزم تفعيل صلاحية «الوصول إلى بيانات الاستخدام» من الزر أدناه."
        }

        // Remove old rendered card panels, retaining the header and action buttons.
        while (root.childCount > 5) root.removeViewAt(5)

        cards.forEach { card ->
            if (card.active && current != null) {
                card.usedBytes = (current - card.startBytes).coerceAtLeast(0L)
            }
            val remaining = (card.totalBytes - card.usedBytes).coerceAtLeast(0L)
            val timeLeft = (card.startedAt + card.durationMs - now).coerceAtLeast(0L)
            val expired = now >= card.startedAt + card.durationMs || remaining == 0L
            if (expired) card.active = false

            val panel = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(18, 16, 18, 16)
                setBackgroundColor(0xFFFFFFFF.toInt())
            }
            val heading = TextView(this).apply {
                text = card.name + if (card.active) "  • نشط" else "  • منتهٍ"
                textSize = 19f
                setTextColor(0xFF16324F.toInt())
            }
            val details = TextView(this).apply {
                textSize = 15f
                setTextColor(0xFF333333.toInt())
                text = "الباقة: ${fmt(card.totalBytes)} GB\n" +
                    "المستهلك: ${fmt(card.usedBytes)} GB\n" +
                    "المتبقي: ${fmt(remaining)} GB\n" +
                    "الوقت المتبقي: ${formatDuration(timeLeft)}\n" +
                    "بدأ: ${DateFormat.getDateTimeInstance().format(Date(card.startedAt))}"
            }
            val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 1000
                progress = ((card.usedBytes.toDouble() / card.totalBytes.coerceAtLeast(1L)) * 1000).toInt().coerceIn(0, 1000)
            }
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val finish = Button(this).apply {
                text = "إنهاء الكرت"
                isEnabled = card.active
                setOnClickListener { card.active = false; saveCards(); refreshCards() }
            }
            val delete = Button(this).apply {
                text = "حذف"
                setOnClickListener {
                    cards.remove(card); saveCards(); refreshCards()
                }
            }
            actions.addView(finish); actions.addView(delete)
            panel.addView(heading); panel.addView(details); panel.addView(bar); panel.addView(actions)
            val params = LinearLayout.LayoutParams(-1, -2).apply { topMargin = 16 }
            root.addView(panel, params)
        }
        saveCards()
    }

    private fun fmt(bytes: Long): String = String.format("%.2f", bytes / GB)
    private fun formatDuration(ms: Long): String {
        val totalMinutes = TimeUnit.MILLISECONDS.toMinutes(ms)
        val days = totalMinutes / 1440
        val hours = (totalMinutes % 1440) / 60
        val minutes = totalMinutes % 60
        return if (days > 0) "$days يوم و $hours ساعة"
        else if (hours > 0) "$hours ساعة و $minutes دقيقة"
        else "$minutes دقيقة"
    }

    private fun saveCards() {
        val array = JSONArray()
        cards.forEach {
            array.put(JSONObject().apply {
                put("id", it.id); put("name", it.name); put("total", it.totalBytes)
                put("duration", it.durationMs); put("started", it.startedAt)
                put("startBytes", it.startBytes); put("used", it.usedBytes); put("active", it.active)
            })
        }
        prefs.edit().putString("items", array.toString()).apply()
    }

    private fun loadCards() {
        try {
            val array = JSONArray(prefs.getString("items", "[]"))
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                cards.add(Card(
                    o.getLong("id"), o.getString("name"), o.getLong("total"),
                    o.getLong("duration"), o.getLong("started"), o.getLong("startBytes"),
                    o.optLong("used", 0), o.optBoolean("active", true)
                ))
            }
        } catch (_: Exception) { }
    }

    override fun onResume() {
        super.onResume()
        if (::root.isInitialized) refreshCards()
    }
}
